const duration = 3000;

setTimeout(() => {
    const element = document.getElementById('FlashMessage');
    element.remove();
}, duration);
