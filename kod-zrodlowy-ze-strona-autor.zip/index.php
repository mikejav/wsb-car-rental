<?php

require_once('./common/bootstrap.php');

guardPage();

require_once('templates/header.php');

?>
Strona główna
<?php

require_once('templates/footer.php');
