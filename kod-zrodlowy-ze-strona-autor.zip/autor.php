<?php

require_once('./common/bootstrap.php');
require_once('templates/header.php');

?>
<center>
    <h1>Michał Jaworski</h1>
    Moja ocena projektu (max35): 35<br/>
    Mój stopień uczestnictwa w projekcie: 70%
</center>
<?php

require_once('templates/footer.php');
