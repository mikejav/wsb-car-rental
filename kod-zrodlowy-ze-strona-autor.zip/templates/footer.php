<?php
// plik zawiera dół HTMLu strony
?>

</div><!-- zamknięcie .container -->

<footer class="footer mt-auto py-3 bg-white">
  <div class="container">
    <span class="text-muted">Copyright © <?= date("Y") ?></span>
  </div>
</footer>

<script src="hide-falsh-message.js"></script>

</body>
</html>
